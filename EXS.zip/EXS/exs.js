//ex1
function exercicio1(){
    let n1 = document.getElementById("N1").value
    let n2 = document.getElementById("N2").value

    let r = (n1 - n2)
    alert(r)
}
//ex2
function exercicio2(){
    let n1 = document.getElementById("N1").value
    let n2 = document.getElementById("N2").value
    let n3 = document.getElementById("N2").value
    let r = (n1 * n2 * n3)
    alert(r)
}
//ex3
function exercicio3(){
    let n1 = document.getElementById("N1").value
    let n2 = document.getElementById("N2").value

    let r = (n1 / n2)
    alert(r)}
//ex 4
function exercicio4(){
    let n1 = Number(document.getElementById("N1").value)
    let n2 = Number(document.getElementById("N2").value)

    let media = (n1 * 2 + n2 * 3)/2
    alert(media)}
//5
function exercicio5(){
    let n1 = Number(document.getElementById("N1").value)

    let r = n1 - (10/100*n1)
    alert(r)}
//6
function exercicio6() {
    let n1 = Number(document.getElementById("N1").value);
    let n2 = Number(document.getElementById("N2").value);
    let comissao = 4 / 100 * n2;
    let salarioreal = comissao + n1;

    alert(salarioreal);
}
//7
function exercicio7() {
    let n1 = Number(document.getElementById("N1").value);
     
    let mais15 = n1 + 15/100*n1
    let menos20 = n1 - (20/100*n1)
    
    alert("se engordar " + mais15 + ", se emagrecer " + menos20);}
//8
function exercicio8() {
    let n1 = Number(document.getElementById("N1").value);
     
    let peso = n1 * 1000
    
    alert(peso + "gramas");}
//9
function exercicio9(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let n3 = Number(document.getElementById("n3").value)

    let Area = ((n1 + n2) * n3) / 2

    alert(Area)}
//10
function exercicio10(){
    let n1 = Number(document.getElementById("n1").value)

    let Area = (n1 * n1)

    alert(Area)}
function exercicio11(){
   let n1 = Number(document.getElementById("n1").value)
   let n2 = Number(document.getElementById("n2").value)
   let n3 = Number(document.getElementById("n3").value)
   let n4 = Number(document.getElementById("n4").value) 
   let media = (n1 + n2 + n3 + n4) / 4
   if (media<=7 ){alert("Reprovado")}
   else{ alert("Aprovado")}
}
function Exercicio12(){
   let n1 = Number(document.getElementById("n1").value)
   let n2 = Number(document.getElementById("n2").value)
   let media = (n1 + n2) / 2
   if (media<3){alert("Reprovado")}
   else if (media<=7){alert("Exame")}
   else if (media>7){alert("Aprovado")}
}
function Exercicio13(){
   let n1 = Number(document.getElementById("n1").value)
   let n2 = Number(document.getElementById("n2").value)
   if (n1<n2){alert(n1)}
   else if (n2<n1){alert(n2)}
}
function exercicio14(){
   let n1 = Number(document.getElementById("n1").value)
   let n2 = Number(document.getElementById("n2").value)
   if (n1<n2){alert(n2)}
   else if (n2<n1){alert(n1)}
}
function exercicio15(){
    let n1 = Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    let op = Number(document.getElementById("op").value)
  switch(op){
      case 0:
        media = (n1 + n2) / 2
        alert(media)
        break;
    
    case 1:
        if (n1>n2)
        alert (n1 - n2)
        else if (n2>n1)
        alert (n2 - n1)
        break;
    case 2:
        resultado = n1 * n1
        alert(resultado)
        break;
    case 3:
        resultado = n1 / n2
        alert(resultado)
  }
    


      
}
